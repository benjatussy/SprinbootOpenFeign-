package com.clubdeportivo2.servicioreservas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.clubdeportivo2.servicioreservas.model.Reserva;
import com.clubdeportivo2.servicioreservas.services.ReservaServices;

@RestController
@RequestMapping("/api/reservas")
public class ReservaController {

    @Autowired
    private ReservaServices reservaService;

    @GetMapping
    public List<Reserva> listarReservas(){
        return reservaService.listarReservas();
    }

    @PostMapping
    public ResponseEntity<?> reservar(@RequestBody Reserva reserva) {
        try {
            Reserva nueva = reservaService.crearReserva(reserva);
            return new ResponseEntity<>(nueva, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            // Retorna el mensaje de "No existe" con un 400 o 404
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/cancha/{id}")
    public List<Reserva> buscarPorCancha(@PathVariable Long id){
        return reservaService.buscarReservasPorCancha(id);
    }


}
